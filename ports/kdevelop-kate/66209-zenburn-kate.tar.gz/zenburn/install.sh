#!/bin/sh

cat ./kateschemarc.zenburn >> ~/.kde/share/config/kateschemarc
cat ./katesyntaxhighlightingrc.zenburn >> ~/.kde/share/config/katesyntaxhighlightingrc
